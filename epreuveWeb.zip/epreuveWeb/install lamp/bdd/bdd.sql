# ATTENTION Il faut creer une base FicBase  

# mais aussi modifier la connexion de
# la page membres.php avec les parametres host et mdp

CREATE TABLE `FicBase`.`utilisateurs`
(
	`id` INT NOT NULL AUTO_INCREMENT,
	`login` VARCHAR( 20 ) NOT NULL,
	`password` VARCHAR( 20 ) NOT NULL,
	`date` DATE NOT NULL,
	PRIMARY KEY ( `id` )
);

INSERT INTO `FicBase`.`utilisateurs` (`id`, `login`, `password`, `date`)
VALUES
	(NULL, 'Admin', 'ght1@bMé8li', '2016-01-17'),
	(NULL, 'shnappy', 'nimp', '2016-01-01');
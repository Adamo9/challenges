<?php

if(isset($_POST['password']))
{
	
	if($_POST['password']=="ght1@bM&8li" && $_POST['password']="Admin" )
	{
		echo "<div><h1>FLAG: faCile59!</h1></div> ";
	}else
		echo "Erreur : 'login=".$_POST['login']."', password='".$_POST['password']."' from 'utilisateurs' ";
}

?>

<html>
<head>
<META HTTP-EQUIV="Refresh" >
<title>fic 2016</title>
<link href="css/commun.css" rel="stylesheet" type="text/css" />
<link href="css/portlets.css" rel="stylesheet" type="text/css" />

</head>
<body>
<h1 class="nonvisible">Fic2016</h1>
<div ">
  <div >
    <div id="fullSite">
      <div id="header">
        
        <div id="btRetourHome"><a href="index.html"><img src="images/transparent.gif" alt="retour à la page d'accueil"/><span>Retour à la page d'accueil</span></a></div>
        <hr class="nonvisible clear" />
      </div>
      <div id="colonnage">
        <div id="colLeft">&nbsp;</div>
        <div id="colRight">
          <h2 class="nonvisible">mp:non ca serait trop facile</h2>
          
          <h3 class="titlePage"> Back office CCAS</h3>
          <div id="fondHeaderContenu">
		  <form action="" method="post">
			Login&nbsp;<br/>
			<input type="text" name="login" /><br/><br/>
			Password&nbsp;<br/>
			<input type="password" name="password" /><br/><br/>
	  <br/><br/>
	  <input type="submit" value="connect" /><br/><br/>
	</form>
      </body>
      </html>
		 
		

            
           </div>
            <div class="tableDefault1Footer">
              <div>&nbsp;</div>
            </div>
            
          </div>
        </div>
      </div>
     <div class="clear height20">&nbsp;</div>
      <div id="footer">
        <h2 class="nonvisible">Bas de page</h2>
        <ul>
          
          <li><a href="tecassePasLaTeteCestPasla.asp">Fic</a></li>
          

        </ul>
      </div>
    </div>
  </div>
</div>

</body>
</html>






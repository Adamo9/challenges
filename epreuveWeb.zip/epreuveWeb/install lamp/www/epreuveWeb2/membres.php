<?php 
$id = intval($_GET['id']) ? $_GET['id'] : FALSE;
$pseudo='';
$date='';
$avatar='<img src="images/Avatar.png" alt="" />';
if($id === FALSE)
{
	echo 'Id incorrecte.';
}
else
{ 
	$db = mysql_connect('localhost', 'root', 'root') or die('Erreur de connection');
	mysql_select_db('FicBase', $db) or die('Erreur de selection');
  if(preg_match('#insert#',$id) || preg_match('#update#',$id) || preg_match('#delete#',$id) ||preg_match('#grant#',$id)  || preg_match('#drop#',$id) || preg_match('#create#',$id))
	{
			echo " Le sujet ne te demande d'inserer, modifier, supprimer .... ";
      exit();
	} 
	else if(($sql = mysql_query("SELECT * FROM utilisateurs WHERE id=".$id)) === FALSE)
	{
		echo 'Erreur SQL';
		$id='';
		$pseudo='Erreur SQL';
		$date='';
	}
	else if(mysql_num_rows($sql) != 1)
	{
		echo 'l\' Utilisateur n\'existe pas.';
		$id=''; 
		$pseudo='l\' utilisateur n\'existe pas';
		$date='';
	}
	
	else { 
		$data = mysql_fetch_array($sql);		
		$id=$data['id'];
		$pseudo=$data['login'];
		$date=$data['date'];
		$avatar='<img src="images/'.$pseudo.'.png" alt="" />';
	}
	
} 
?>

<html>
<head>
<META HTTP-EQUIV="Refresh" >
<title>fic 2016</title>
<link href="css/commun.css" rel="stylesheet" type="text/css" />
<link href="css/portlets.css" rel="stylesheet" type="text/css" />
<meta charset="UTF-8">
</head>
<body>
<h1 class="nonvisible">Fic2016</h1>
<div ">
  <div >
    <div id="fullSite">
      <div id="header">
        
        <div id="btRetourHome"><a href="index.html"><img src="images/transparent.gif" alt="retour à la page d'accueil"/><span>Retour à la page d'accueil</span></a></div>
        <hr class="nonvisible clear" />
      </div>
      <div id="colonnage">
        <div id="colLeft">&nbsp;</div>
        <div id="colRight">
          <h2 class="nonvisible">mp:non ca serait trop facile</h2>
          
          <h3 class="titlePage"> Membres connectés </h3>
          <div id="fondHeaderContenu">
 <div class="tableDefault1Header"><div></div></div>
            <div class="tableDefault1Data">
              <div>
                <table class="tableDefault1" cellspacing="0" cellpadding="0" summary="Marchés publics">
                  <caption>
                  Membres connectés
                  </caption>
                  <tr>
                    <th class="width12po" scope="col" id="talbe_num">Avatar
                      <span><a href="#"><img src="images/fleche1.gif" alt="trier dans l'ordre croissant" /></a><a href="#"><img src="images/fleche2.gif" alt="trier dans l'ordre d�croissant" /></a></span></th>
                    <th id="table_descript" class="width25po" scope="col">id</th>
                    <th id="table_limit" class="width19po" scope="col">Pseudo
                      <span><a href="#"><img src="images/fleche1.gif" alt="trier dans l'ordre croissant" /></a><a href="#"><img src="images/fleche2.gif" alt="trier dans l'ordre d�croissant" /></a></span></th>
                    <th id="table_download" class="width28po" scope="col">dernière connexion
                      <span><a href="#"><img src="images/fleche1.gif" alt="trier dans l'ordre croissant" /></a><a href="#"><img src="images/fleche2.gif" alt="trier dans l'ordre d�croissant" /></a></span></th>
                    <th id="table_detail" class="width16po" scope="col">connecté
                      <span><a href="#"><img src="images/fleche1.gif" alt="trier dans l'ordre croissant" /></a><a href="#"><img src="images/fleche2.gif" alt="trier dans l'ordre d�croissant" /></a></span></th>
                  </tr>
                  <tr class="paire">
                    <td headers="talbe_num"><?php echo $avatar; ?></td>
                    <td headers="table_descript"><?php echo $id ?></td>
                    <td headers="table_limit"><div class="limDptDate"><?php echo $pseudo ?>
                    </td>
                    <td headers="table_download"><?php echo $date ?></td>
                    <td headers="table_detail"><div class="limDptFeu"><img src="images/rondR.gif" alt="Rouge" /></td>
                  </tr>
				 </table>
				</div>
			
	
           </div>
            <div class="tableDefault1Footer">
              <div>&nbsp;</div>
            </div>
            
          </div>
        </div>
      </div>
     <div class="clear height20">&nbsp;</div>
      <div id="footer">
        <h2 class="nonvisible">Bas de page</h2>
        <ul>
          
          <li><a href="tecassePasLaTeteCestPasla.asp">Fic</a></li>
          

        </ul>
      </div>
    </div>
  </div>
</div>

</body>
</html>
// scroll sur portlet

function initScrollPortlet(){
	$('portletInfoPrat').setStyles({height:'181px'});
	$('area').setStyles({height:'150px'});
	$('conteneur').setStyles({height:'150px', overflow:'hidden'});
	comp=(setTimeout("scrollPortlet()",1000));
}
var annoy=null;
var mySlide=null;
function scrollPortlet(){
/* Function de la scrollbar - au clic sur la barre ou le curseur ------------------ */
	// stop l'animation si click
	$('knob').addEvent('mouseenter', function(e){
		e = new Event(e);
		killTempo();
		e.stop();
	});
	$('knob').addEvent('mouseleave', function(e){
		e = new Event(e);
		lectureAuto();
		e.stop();
	});
	// calcul
	txtarea_y = $('txtarea').getSize().size.y;
	conteneur_y = $('conteneur').getSize().size.y;
	top_maxi = txtarea_y - conteneur_y;
	// effet slider
	mySlide = new Slider('area', 'knob', {	
		steps: top_maxi,	
		mode: 'vertical',	
		onChange: function(step){
			$('conteneur').scrollTo(0, step);
		},
    	onComplete: function(){}
	}).set(0);
	// animation lanc�e pour lecture auto	
	lectureAuto();
}
// stop la temporisation auto
function killTempo(){
	$clear(annoy);
}
function lectureAuto(){
	annoy = (function(){ 
		if(this.step == this.options.steps) this.set(0);
		this.set(this.step+=1);		
	}).periodical(30, mySlide);
}
<!--
var tabInfo = navigator.appVersion.split(';');
/*tabInfo[1] != " U" -> pour op�ra*/
if(tabInfo[1] != " MSIE 7.0" && tabInfo[1] != " U")
{
   if (window.attachEvent) {
		window.attachEvent("onload", correct_png);
	}
}
function correct_png()
{
	//url de l'image dont le filtre se sert pour g�n�rer la transparence
	//url relative � la page html
	var path = 'images/correct_transparent_png.gif';

    //Pour les images PNG en dur dans la page
	var images_list = document.getElementsByTagName('img');
	for(var i=0 ; i<images_list.length ; i++)
    {
		var img		= document.images[i];
		var imgName	= img.src.toUpperCase();
		if (imgName.substring(imgName.length - 3, imgName.length) == 'PNG'){
				img.src = path;						
				img.style.cssText += ";filter: progid:DXImageTransform.Microsoft.AlphaImageLoader( src='" + imgName + "', sizingMethod='scale' );";
				i--;
		}
    }

    //Pour les images PNG appell�e via le css
    var images_list = document.getElementsByTagName('div') ;
    for(var i=0 ; i<images_list.length; i++)
    {
        var image_name = images_list[i].currentStyle.backgroundImage.replace(/url[s]*()+/, '');

        image_name = image_name.replace(/(")+/g, '');
        image_name = image_name.substr(1, image_name.length-1);
        image_name = image_name.substr(0, image_name.length-1);

        if(image_name.substring(image_name.length-3, image_name.length) == 'png')
        {
            images_list[i].runtimeStyle.backgroundImage = 'url(../path)';
            images_list[i].runtimeStyle.filter = "progid:DXImageTransform.Microsoft.AlphaImageLoader(src='" + image_name + "', sizingMethod='scale')";
        }
    }
	
    return true;
}
//-->
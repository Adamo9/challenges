// JavaScript commun
function openWindow(url) {
	var largeur=400;
	var hauteur=600;
	var leftVal = (screen.width-largeur) / 2;
	var topVal = (screen.height-hauteur) / 2;
  window.open(url,'','scrollbars=yes,width='+largeur+',height='+hauteur+',left='+leftVal+', top='+topVal);
}